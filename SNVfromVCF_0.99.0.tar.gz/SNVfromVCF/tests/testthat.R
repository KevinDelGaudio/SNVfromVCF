library(testthat)
library(SNVfromVCF)
test_local("C:/Users/WIN/Documents/Università/Magistrale/Scientific Programming/proj/vcf/SNVfromVCF")
