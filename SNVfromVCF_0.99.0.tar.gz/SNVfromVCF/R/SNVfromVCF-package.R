#' @keywords internal
#' @docType package
#' @import VariantAnnotation tidyverse
"_PACKAGE"
