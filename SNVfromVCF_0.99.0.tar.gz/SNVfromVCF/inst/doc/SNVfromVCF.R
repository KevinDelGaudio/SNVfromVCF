## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(SNVfromVCF)

## -----------------------------------------------------------------------------
path <- system.file("example-data", "example.vcf", package="SNVfromVCF")
vcf <- PreprocessVCF(path)

## -----------------------------------------------------------------------------
genome <- PreprocessGenome(genome = "hg38", vcf = vcf)

## -----------------------------------------------------------------------------
mut_types <- MutationsTable(vcf = vcf, genome = genome, context_length = 3)
mut_types

## ----fig.dim = c(10, 7)-------------------------------------------------------
count_table <- TypeCounts(mut_types, plot = TRUE)

